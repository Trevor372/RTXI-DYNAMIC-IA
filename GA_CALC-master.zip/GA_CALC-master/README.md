# GA_Calc_SGA
