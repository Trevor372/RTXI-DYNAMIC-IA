# Dave_Neuron
This neuron is up to date as of 07/16/19
